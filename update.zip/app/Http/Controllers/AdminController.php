<?php

namespace App\Http\Controllers;

use App\Models\Pesanan;
use App\Models\Harga;
use Illuminate\Http\Request;
use Carbon\Carbon;

class AdminController extends Controller
{
    // Dashboard Admin
    public function dashboard()
    {
        return view('admin.dashboard');
    }


    // Kelola Pesanan
    public function kelolaPesanan()
    {
        $pesanans = Pesanan::all();
        return view('admin.kelola', compact('pesanans'));
    }

    // Update pesanan
    public function update(Request $request, $id)
    {
        $pesanan = Pesanan::findOrFail($id);
        $pesanan->status = $request->input('status');
        $pesanan->jumlah = $request->input('jumlah');

        $hargaRecord = Harga::where('layanan', $pesanan->layanan)->first();

        if ($hargaRecord && $pesanan->jumlah) {
            $pesanan->total_harga = $pesanan->jumlah * $hargaRecord->hargaPerKg;
        } else {
            $pesanan->total_harga = 0;
        }

        $pesanan->save();

        return redirect()->back()->with('success', 'Pesanan berhasil diperbarui');
    }

    // Kelola Harga
    public function kelolaHargaPesanan()
    
    {
        $hargas = Harga::all();
        return view('admin.harga', compact('hargas'));
    }
}
